# Deal Tech — Landing Page

Landing page statis, satu file, siap di-hosting.

## Cara pakai

1. Upload isi folder ini ke repository GitHub Anda.
2. Buka **Settings → Pages**, pilih branch `main` dan folder `/ (root)`, lalu **Save**.
3. Halaman akan tayang di `https://<username>.github.io/<nama-repo>/`.

Semua gambar, font, dan script sudah tertanam di dalam `index.html`, jadi tidak ada file lain yang perlu diunggah dan tidak butuh build step. Bisa juga di-drop langsung ke Netlify, Vercel, atau cPanel.

## Yang perlu disesuaikan sebelum tayang

- **Nomor WhatsApp** — cari `6281234567890` di `index.html` dan ganti dengan nomor Anda (format 62, tanpa tanda + atau spasi).
- **Email & jam operasional** di footer: `hello@dealtech.id`, `Senin–Sabtu, 09.00–18.00 WIB`.
- **Testimoni** — nama dan kota masih contoh (Rizal Hakim, Sari Wulandari, Andi Prasetyo). Ganti dengan klien asli.
- **Harga** — Rp600rb / Rp3jt / mulai Rp7jt, beserta harga coret dan opsi cicilan.
- **Durasi promo** — countdown default 14 hari, cari `hariPromo` di bagian script.
